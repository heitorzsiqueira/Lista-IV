import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcao = 0;

        do {
            System.out.println("\n===== MENU DE EXERCÍCIOS =====");
            System.out.println("1 - Validar nota");
            System.out.println("2 - Validar usuário e senha");
            System.out.println("3 - Validar informações pessoais");
            System.out.println("4 - Crescimento populacional fixo");
            System.out.println("5 - Crescimento populacional customizado");
            System.out.println("6 - Imprimir números de 1 a 20");
            System.out.println("7 - Maior de 5 números");
            System.out.println("8 - Soma e média de 5 números");
            System.out.println("9 - Números ímpares de 1 a 50");
            System.out.println("10 - Intervalo entre dois números");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // limpar buffer

            switch (opcao) {
                case 1:
                    validarNota(scanner);
                    break;
                case 2:
                    validarUsuarioSenha(scanner);
                    break;
                case 3:
                    validarInformacoes(scanner);
                    break;
                case 4:
                    crescimentoPopulacionalFixo();
                    break;
                case 5:
                    crescimentoPopulacionalCustomizado(scanner);
                    break;
                case 6:
                    imprimirNumeros();
                    break;
                case 7:
                    maiorNumero(scanner);
                    break;
                case 8:
                    somaMedia(scanner);
                    break;
                case 9:
                    imprimirImpares();
                    break;
                case 10:
                    intervaloNumeros(scanner);
                    break;
                case 0:
                    System.out.println("Encerrando o programa...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);

        scanner.close();
    }

    static void validarNota(Scanner scanner) {
        int nota;
        do {
            System.out.print("Digite uma nota entre 0 e 10: ");
            nota = scanner.nextInt();
            if (nota < 0 || nota > 10) {
                System.out.println("Nota inválida!");
            }
        } while (nota < 0 || nota > 10);
        System.out.println("Nota válida: " + nota);
    }

    static void validarUsuarioSenha(Scanner scanner) {
        String usuario, senha;
        do {
            System.out.print("Digite o nome de usuário: ");
            usuario = scanner.nextLine();
            System.out.print("Digite a senha: ");
            senha = scanner.nextLine();
            if (usuario.equals(senha)) {
                System.out.println("Erro: senha não pode ser igual ao nome de usuário.");
            }
        } while (usuario.equals(senha));
        System.out.println("Usuário e senha válidos.");
    }

    static void validarInformacoes(Scanner scanner) {
        String nome;
        int idade;
        double salario;
        char sexo, estadoCivil;

        do {
            System.out.print("Nome: ");
            nome = scanner.nextLine();
        } while (nome.length() <= 3);

        do {
            System.out.print("Idade: ");
            idade = scanner.nextInt();
        } while (idade < 0 || idade > 150);

        do {
            System.out.print("Salário: ");
            salario = scanner.nextDouble();
        } while (salario <= 0);

        do {
            System.out.print("Sexo (f/m): ");
            sexo = scanner.next().toLowerCase().charAt(0);
        } while (sexo != 'f' && sexo != 'm');

        do {
            System.out.print("Estado civil (s/c/v/d): ");
            estadoCivil = scanner.next().toLowerCase().charAt(0);
        } while (estadoCivil != 's' && estadoCivil != 'c' && estadoCivil != 'v' && estadoCivil != 'd');

        System.out.println("Informações válidas!");
        scanner.nextLine(); // limpar buffer
    }

    static void crescimentoPopulacionalFixo() {
        int populacaoA = 80000;
        int populacaoB = 200000;
        int anos = 0;

        while (populacaoA <= populacaoB) {
            populacaoA += populacaoA * 0.03;
            populacaoB += populacaoB * 0.015;
            anos++;
        }

        System.out.println("Serão necessários " + anos + " anos para a população de A ultrapassar B.");
    }

    static void crescimentoPopulacionalCustomizado(Scanner scanner) {
        int populacaoA, populacaoB;
        double taxaA, taxaB;

        do {
            System.out.print("Informe a população do país A: ");
            populacaoA = scanner.nextInt();
            System.out.print("Informe a população do país B: ");
            populacaoB = scanner.nextInt();
        } while (populacaoA <= 0 || populacaoB <= 0 || populacaoA >= populacaoB);

        do {
            System.out.print("Informe a taxa de crescimento de A (%): ");
            taxaA = scanner.nextDouble();
            System.out.print("Informe a taxa de crescimento de B (%): ");
            taxaB = scanner.nextDouble();
        } while (taxaA <= 0 || taxaB <= 0);

        int anos = 0;
        while (populacaoA <= populacaoB) {
            populacaoA += populacaoA * (taxaA / 100);
            populacaoB += populacaoB * (taxaB / 100);
            anos++;
        }

        System.out.println("Serão necessários " + anos + " anos para A ultrapassar B.");
    }

    static void imprimirNumeros() {
        System.out.println("Números de 1 a 20 (um abaixo do outro):");
        for (int i = 1; i <= 20; i++) {
            System.out.println(i);
        }

        System.out.println("\nNúmeros de 1 a 20 (lado a lado):");
        for (int i = 1; i <= 20; i++) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    static void maiorNumero(Scanner scanner) {
        int maior = Integer.MIN_VALUE;

        for (int i = 0; i < 5; i++) {
            System.out.print("Digite um número: ");
            int num = scanner.nextInt();
            if (num > maior) {
                maior = num;
            }
        }

        System.out.println("O maior número é: " + maior);
    }

    static void somaMedia(Scanner scanner) {
        int soma = 0;

        for (int i = 0; i < 5; i++) {
            System.out.print("Digite um número: ");
            soma += scanner.nextInt();
        }

        double media = soma / 5.0;
        System.out.println("Soma: " + soma);
        System.out.println("Média: " + media);
    }

    static void imprimirImpares() {
        System.out.println("Números ímpares de 1 a 50:");
        for (int i = 1; i <= 50; i++) {
            if (i % 2 != 0) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }

    static void intervaloNumeros(Scanner scanner) {
        System.out.print("Digite o primeiro número: ");
        int num1 = scanner.nextInt();
        System.out.print("Digite o segundo número: ");
        int num2 = scanner.nextInt();

        if (num1 > num2) {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        System.out.println("Números entre " + num1 + " e " + num2 + ":");
        for (int i = num1 + 1; i < num2; i++) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}
